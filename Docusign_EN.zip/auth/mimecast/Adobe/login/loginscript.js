function resetForm() {
 // var useOpenID = getElement("useOpenIDInput");
 // useOpenID.checked = false;
}

function doOpenIDSubmit() {
  var openID = getElementText("useOpenIDEdit");
  if (openID != "") {
    if (openID.indexOf("http://") == -1) {
      openID = "/webMail/authenticate.jsp?openid=" + openID;
    }
    window.open(openID, '', 'scrollbars=yes, menubar=no, height=800, width=1000, resizable=yes, toolbar=no, locatiomn=yes, status=yes');
  }
}

function doLoginSubmit() {
	var form = getElement("loginForm");
	if (form != undefined) {
		form.action = "/webMail/logon";
		form.submit();
	}
	return true;
}

function doResetSubmit() {
	var form = getElement("loginForm");
	if (form != undefined) {
		form.action = "/webMail/logon?mode=reset";
		form.submit();
	}
	return true;
}

function doChangePasswordSubmit() {
	var form = getElement("loginForm");
	if (form != undefined) {
		form.action = "/webMail/logon?mode=change";
		form.submit();
	}
	return true;
}

function useOpenID() {
  var element = getElement("useOpenIDInput");
  if (element) {
    if (element.checked) {
      // toggleBox("openIDLabel", 1, 1);
      // MPP-52 : Some of the default styles in IE are different to Firefox and Safari so force styles
      toggleBox("openIDField", 1, 1);
      toggleBox("openIDFieldDummy", 0, 0);
      toggleBox("submitLogin", 0, 0);
      toggleBox("submitOpenID", 1, 1);
      // toggleBox("releaseNotes", 1, 1);
      toggleBox("submitReset", 0, 0);
      toggleBox("loginFormAuthorizationReal", 0, 0);
      toggleBox("loginFormAuthorizationDummy", 0, 0);
      toggleBox("labelConfirmPassword", 0, 0);
      toggleBox("editConfirmPassword", 0, 0);
      toggleBox("authorizationCodeLabel", 0, 0);
      toggleBox("messages", 1, 1);
      // toggleBox("loginFormMain", 1, 1);
      var label = getElement("labelPassword");
      label.innerHTML = "Password";
    }
    else {
      // toggleBox("openIDLabel", 0, 0);
      toggleBox("openIDField", 0, 0);
      toggleBox("openIDFieldDummy", 1, 1);
      toggleBox("submitLogin", 1, 1);
      toggleBox("submitOpenID", 0, 0);
      // toggleBox("releaseNotes", 1, 1);
      toggleBox("submitReset", 0, 0);
      toggleBox("loginFormAuthorizationReal", 0, 0);
      toggleBox("loginFormAuthorizationDummy", 0, 0);
      toggleBox("labelConfirmPassword", 0, 0);
      toggleBox("editConfirmPassword", 0, 0);
      toggleBox("authorizationCodeLabel", 0, 0);
      toggleBox("messages", 1, 1);
      // toggleBox("loginFormMain", 1, 1);
      var label = getElement("labelPassword");
      label.innerHTML = "Password";
    }
  }
}

function showLoginReset() {
  if (getUsername() != "") {
    if (confirm("Do you really want to reset your password?")) 
    {
      // toggleBox("loginFormMain", 0, 0);
      toggleBox("submitLogin", 0, 0);
      // MPP-52 : Tidy up the login form based on various options
      toggleBox("submitOpenID", 0, 0);
      toggleBox("submitReset", 1, 1);
      toggleBox("labelPassword", 1, 1);
      toggleBox("divPassword", 1, 1);
      toggleBox("labelConfirmPassword", 1, 1);
      toggleBox("editConfirmPassword", 1, 1);
      toggleBox("loginFormAuthorizationReal", 1, 1);
      toggleBox("loginFormAuthorizationDummy", 0, 0);
      toggleBox("authorizationCodeLabel", 1, 1);
      toggleBox("loginFormMain", 0, 0);
     // toggleBox("releaseNotes", 0, 0);
      toggleBox("messages", 0, 0);
      var label = getElement("labelPassword");
      label.innerHTML = "New Password";
      // AJAX request to send authorization code
      sendResetPasswordRequest();
    }
  } else {
    alert("Email Address is not allowed to be blank");
  }
}


function getUsername() {
  return getElementText("loginForm:editUsername");
}

function getPassword() {
  return getElementText("loginForm:editPassword");
}

function getPasswordConfirm() {
  return getElementText("editConfirmPassword");
}

function getAuthorizationCode() {
  return getElementText("loginForm:authorizationCode");
}


function sendResetPasswordRequest() {
	// Ensure the username field is not blank
	if (getUsername() != "") {
		// call the password reset function.
		// An authorization code will be sent to the user and this is used to reset the password
		var xmlhttp;
		if (window.XMLHttpRequest) {
			// code for IE7+, Firefox, Chrome, Opera, Safari
			xmlhttp=new XMLHttpRequest();
		} else if (window.ActiveXObject) {
			// code for IE6, IE5
			xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
		} else {
			alert("Your browser does not support AJAX!");
		}
		if (xmlhttp != undefined) {
			// We have an XMLHTTP object so request a password reset
			// try to validate the email address a little to make sure this is not garbage
			xmlhttp.onreadystatechange  = function() { 
				if(xmlhttp.readyState == 4)	{
					if(xmlhttp.status == 200) {
						document.ajax.dyn="Received:"  + xmlhttp.responseText;
					} else { 
						document.ajax.dyn="Error code " + xmlhttp.status + " : " + xmlhttp.statusText;
					}
				}
			}; 

			var url  = "/webMail/resetPasswordRequest?emailaddress=" + getUsername();
			var data = "emailaddress=" + getUsername();
			xmlhttp.open("POST", url, true)
			xmlhttp.send(data);
		}
	} else {
		alert("Email Address is not allowed to be blank");
	}
}

function sendConfirmResetPassword() {
	// Ensure the username field is not blank
	if (getUsername() != "") {
		// call the password reset function.
		// An authorization code will be sent to the user and this is used to reset the password
		var xmlhttp;
		if (window.XMLHttpRequest) {
			// code for IE7+, Firefox, Chrome, Opera, Safari
			xmlhttp=new XMLHttpRequest();
		} else if (window.ActiveXObject) {
			// code for IE6, IE5
			xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
		} else {
			alert("Your browser does not support AJAX!");
		}
		if (xmlhttp != undefined) {
			// We have an XMLHTTP object so request a password reset
			// try to validate the email address a little to make sure this is not garbage

			xmlhttp.onreadystatechange  = function() { 
				if(xmlhttp.readyState == 4) {
					if(xmlhttp.status == 200) {
						document.ajax.dyn="Received:"  + xmlhttp.responseText;
					} else { 
						document.ajax.dyn="Error code " + xmlhttp.status + " : " + xmlhttp.statusText;
					}
				}
			}; 
			var emailAddress      = getUsername();
			var resetPassword     = getPassword();
			var authorizationCode = getAuthorizationCode();

			var url  = "/webMail/confirmResetPasswordRequest?"
			url += "emailaddress="       + emailAddress;
			url += "&newpassword="       + resetPassword;
			url += "&authorizationcode=" + authorizationCode;
			var data = "emailaddress="    + emailAddress;
			data += "&newpassword="       + resetPassword;
			data += "&authorizationcode=" + authorizationCode;
			xmlhttp.open("POST", url, true)
			xmlhttp.send(data);
		}
	} else {
		alert("Email Address is not allowed to be blank");
	}
}

