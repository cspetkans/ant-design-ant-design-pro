function toggleBox(szDivID, iVisible, iDisplay) { // 1 visible, 0 hidden
	if(document.layers)	   //NN4+
	{
		document.layers[szDivID].visibility = iVisible ? "show" : "hide";
		document.layers[szDivID].display = iDisplay ? "block" : "none";
	}
	else if(document.getElementById)	  //gecko(NN6) + IE 5+
	{
		var obj = document.getElementById(szDivID);
		obj.style.visibility = iVisible ? "visible" : "hidden";
		obj.style.display = iDisplay ? "block" : "none";
	}
	else if(document.all)	// IE 4
	{
		document.all[szDivID].style.visibility = iVisible ? "visible" : "hidden";
		document.all[szDivID].style.display = iDisplay ? "block" : "none";
	}
}

function getElementText(szElementID) {
	var element = getElement(szElementID);
	if (element) {
		return element.value;
	}
	return "";
}

function getElement(szElementID) {
	var element = null;
	if(document.layers)	   //NN4+
	{
		element = document.layers[szElementID];
	}
	else if(document.getElementById)	  //gecko(NN6) + IE 5+
	{
		element = document.getElementById(szElementID);
	}
	else if(document.all)	// IE 4
	{
		element = document.all[szElementID];
	}
	return element;
}


function are_cookies_enabled()
{
    var cookieEnabled = (navigator.cookieEnabled) ? true : false;

    //if (typeof navigator.cookieEnabled == "undefined" && !cookieEnabled)
    {
        document.cookie="testcookie";
        cookieEnabled = (document.cookie.indexOf("testcookie") != -1) ? true : false;
    }
    return (cookieEnabled);
}