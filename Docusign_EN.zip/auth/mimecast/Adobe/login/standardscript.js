/*
 * Mimecast JavaScript Library
 *
*/

// page variables
var contextSelectedObject = null;
var contextSelectedStyle = null;
var triggerActive = false;

// row variables
var rowCounter = 0
var rows = new Array(1000);
var rowToggle = 0;
var rowTrigger;

// row class
function RowObject(context, sel, checked, coldata) {
	this.context = context;
	this.sel = sel;
	this.checked = checked;
	this.coldata = coldata;
}

// DOM based object getter
function getObject(objName) {
	return document.getElementById(objName)
}

// standard trigger call function
function runTrigger(e,triggerName) {
	if (parent.frames.length > 1) {
		if ((parent.frames[0].triggerActive) || (parent.frames[1].triggerActive)) {
			alert('Please wait for the page to complete loading ...');
			return;
		}
	} else {
		if (triggerActive) {
			alert('Please wait for the page to complete loading ...');
			return;
		}
	}
	triggerActive = true;
	document.forms[0].SysTrigger.value = triggerName;
	document.forms[0].submit();
	e.cancelBubble = true;
}

// menu page call
function pageCall(windowCode, trigCode) {
	parent.frames.viewer.document.forms[0].SysNewWindow.value = windowCode;
	parent.frames.viewer.document.forms[0].SysCaller.value = 'connect.explorer';
	parent.frames.viewer.document.forms[0].SysTrigger.value = trigCode;
	parent.frames.viewer.document.forms[0].submit();
}

// page URL based call
function pageURLCall(windowCode, trigCode) {
	url = 'admin?SysCaller=connect.explorer&SysWindow=' + windowCode + '&SysTrigger=' + trigCode;
	parent.frames.viewer.document.location = url;
}

// random menu call
function pageCallRandom(windowCode, trigCode) {

    r1 = Math.round(Math.random()*9);
    r2 = Math.round(Math.random()*9);
    r3 = Math.round(Math.random()*9);
    r4 = Math.round(Math.random()*9);
    r5 = Math.round(Math.random()*9);
    r6 = Math.round(Math.random()*9);
    r7 = Math.round(Math.random()*9);
    r8 = Math.round(Math.random()*9);
    r9 = Math.round(Math.random()*9);
    
    rand = "rn" + r1 + r2 + r3 + r4 + r5 + r6 + r7 + r8 + r9;
    
	pageCall(windowCode + "." + rand, trigCode);
	
}

// context switching
function switchContext(newContext) {
	document.forms[0].SysNewWindow.value = newContext;
	document.forms[0].submit();
}

// window page call
function windowCall(windowCode, trigCode, callerPage, winattr) {
	url = 'admin?SysWindow=' + windowCode + '&SysCaller=' + callerPage + '&SysTrigger=' + trigCode;
	winHandle = window.open(url, windowCode, winattr);
	winHandle.focus();
}

// tree management functions
function expandToggle(imgObjStr, mnuObjStr, type, hideObjStr) {

	imgObj = getObject(imgObjStr);
	mnuObj = getObject(mnuObjStr);
	hideObj = getObject(hideObjStr);

  if (mnuObj.style.display == 'none')	{
    mnuObj.style.display = 'block';
    if (type == 't') {
    	imgObj.src = 'Image/teeminusicon.gif';
    } else {
    	imgObj.src = 'Image/cornerminusicon.gif';
    }
    hideObj.value='1';
    
  }	else {
  
    mnuObj.style.display = 'none';
    if (type == 't') {
    	imgObj.src = 'Image/teeplusicon.gif';
    } else {
    	imgObj.src = 'Image/cornerplusicon.gif';
    }
    hideObj.value='0';

  }
  
}

function showHideObject(clickImage, showObject, expandImage, collapseImage) {

	imgObj = getObject(clickImage);
	showObj = getObject(showObject);

  if (showObj.style.display == 'none')	{
    showObj.style.display = 'block';
    imgObj.src = collapseImage;
  }	else {
    showObj.style.display = 'none';
    imgObj.src = expandImage;
  }
  
}

function deleteConf() {
	if (confirm("This will remove the item and its associated data permanently!") == false) {
		event.cancelBubble = true;
		return false;
	}
	return true;
}

function checkToggle(checkObject, hiddenObject) {
	if (checkObject.checked == true) {
		hiddenObject.value = "true";
	} else {
		hiddenObject.value = "false";
	}
}

function showPopup(e){
	resetHidePopup();
	menuobj = getObject("popupBox");
	dataObj = getObject("StdPopup");
	xpos = e.clientX;
	ypos = e.clientY;
	screenHeight = document.body.clientHeight;
	screenWidth = document.body.clientWidth;
	objectWidth = dataObj.offsetWidth;
	objectHeight = dataObj.offsetHeight;

	if ((xpos + objectWidth + 3) > screenWidth) {
		xOffSet = objectWidth - 2;
	} else {
		xOffSet = 5;
	}

	if ((ypos + objectHeight + 3) > screenHeight) {
		yOffSet = objectHeight - 2;
	} else {
		yOffSet = 5;
	}

	menuobj.style.left = document.body.scrollLeft + xpos - (xOffSet);
	menuobj.style.top = document.body.scrollTop + ypos - (yOffSet);
	menuobj.innerHTML = dataObj.innerHTML;
	e.cancelBubble = true;
	menuobj.style.visibility = "visible";

}

function hidePopup() {
	clearContext();
	menuobj = getObject("popupBox");
	menuobj.style.visibility = "hidden";
	contextSelectedObject.className = contextSelectedStyle;
	contextSelectedObject = null;
	contextSelectedStyle = null;
}

function delayHidePopup() {
	delayAction=setTimeout("hidePopup()",250);
}

function resetHidePopup(){
	if (window.delayAction) {
		clearTimeout(delayAction);
	}
}

function contextObjectOver(obj, newClass) {
	if (contextSelectedObject == null) {
		obj.className = newClass;
	}
}

function contextObjectOut(obj, newClass) {
	if (contextSelectedObject == null) {
		obj.className = newClass;
	}
}

function contextPopup(obj, stl, event) {
	contextSelectedObject = obj;
	contextSelectedStyle = stl;
	showPopup(event);
}

function setContext(contextItem) {
	document.forms[0].SysContextItem.value = contextItem;
}

function clearContext() {
	document.forms[0].SysContextItem.value = '';
}

function selectRow(event, checkObject) {
	checkBox = getObject(checkObject);
	if (checkBox.checked == true) {
		checkBox.checked = false;
	} else {
		checkBox.checked = true;
	}
	event.cancelBubble = true;
}

function logonEnter(event, code) {
	var key = event.keyCode || event.which;
	if (key==13) {
		runTrigger(event, code);
	}
}

function setAttItem(type, point) {

	if (type == 'ctype') {
		obj = getObject('hold_' + point);
		obj.checked = false;
		obj = getObject('holdsize_' + point);
		obj.value = 0;
		obj = getObject('link_' + point);
		obj.checked = false;
		obj = getObject('linksize_' + point);
		obj.value = 0;
	}
	
	if (type == 'hold') {
		obj = getObject('ctype_' + point);
		obj.checked = false;
		obj = getObject('size_' + point);
		obj.value = 0;
		obj = getObject('link_' + point);
		obj.checked = false;
		obj = getObject('linksize_' + point);
		obj.value = 0;
	}

	if (type == 'link') {
		obj = getObject('ctype_' + point);
		obj.checked = false;
		obj = getObject('size_' + point);
		obj.value = 0;
		obj = getObject('hold_' + point);
		obj.checked = false;
		obj = getObject('holdsize_' + point);
		obj.value = 0;
	}

}

function checkSelect(checkObject) {
	valPos = 0;
	while(true) {
		checkName = 'SysChkSel' + valPos;
		chkItem = getObject(checkName);
		if (chkItem == null) {
			break;
		}
		if (checkObject.checked == true) {
			chkItem.checked = true;
		} else {
			chkItem.checked = false;
		}
		valPos += 1;
	}
}

function setRowTrigger(rowClick) {
	rowTrigger = rowClick;
}

function addRowItem(context, sel, checked, coldata) {
	rows[rowCounter++] = new RowObject(context, sel, checked, coldata)
}

function buildRows() {

	var colArray;
	var checkSelect;
	var checkHtml;
	var rowClass;
	
	// static strings
	
	var r1 = '<tr class="';
	var r2 = '" title="Right-Click for options" onclick="setContext(\'';
	var r3 = "');runTrigger(event, '";
	var r4 = '\')" oncontextmenu="setContext(\'';
	var r5 = "');contextPopup(this, '";
	var r6 = '\', event);return false" onmouseover="contextObjectOver(this, \'StdTableMouseOver\')" onmouseout="contextObjectOut(this, \'';
	var r7 = "')\">";
	
	var t1 = '<td><img src="Image/contextmenu.gif"></td>';
	var t2 = '<td onclick="selectRow(event,';
	var t3 = ');" title="Select Row"><input type="checkbox" name="SysChkSel';
	var t4 = '" id = "SysChkSel';
	var t5 = '" onclick="event.cancelBubble=true;"></td>';
	var t6 = '<td align="right" nowrap>';
	var t7 = '<td align="center" nowrap>';
	var t8 = "<td nowrap>";
	
	for (var i=0; i<rowCounter; i++) {
	
		// build row controls
		
		if (rowToggle == 0) {
        	rowClass = "StdTableRow1";
            rowToggle = 1;
        } else {
        	rowClass = "StdTableRow2";
            rowToggle = 0;
        }
        
        document.write(r1 + rowClass + r2 + rows[i].context + r3 + rowTrigger + r4 + rows[i].context + r5 + rowClass + r6 + rowClass + r7);
		
		// build select checkbox
		if (rows[i].sel == (-1)) {
			document.write(t1);
		} else {
			checkSelect = "'SysChkSel" + rows[i].sel + "'";
			document.write(t2 + checkSelect + t3 + rows[i].sel + t4 + rows[i].sel + t5);
		}
		
		// build column data
		colArray = rows[i].coldata.split(",");
		noCols = colArray.length - 1;
		
		for (var j=0; j < noCols; j++) {
		
			// handle column alignment
			if (colArray[j].substring(0, 2) == "1:") {
				document.write(t6);
			} else if (colArray[j].substring(0, 2) == "2:") {
				document.write(t7);
			} else {
				document.write(t8);
			}
			
			// extract raw column data
			document.write(prepUTF8(unescape(colArray[j].substring(2))));
			document.write("</td>");
		}
		
		// close off row
		document.writeln("</tr>");
		
	}
	
	function prepUTF8(s) {
	
  		var c, d = "", flag = 0, tmp;
  
  		for (var i = 0; i < s.length; i++) {
    
    		c = s.charCodeAt(i);
    		if (flag == 0) {
      			if ((c & 0xe0) == 0xe0) {
        			flag = 2; 
        			tmp = (c & 0x0f) << 12;
      			} else if ((c & 0xc0) == 0xc0) {
        			flag = 1;
        			tmp = (c & 0x1f) << 6;
      			} else if ((c & 0x80) == 0) {
        			d += s.charAt (i);
      			} else {
        			flag = 0;
      			}
    		} else if (flag == 1) {
      			flag = 0;
      			d += String.fromCharCode(tmp | (c & 0x3f));
    		} else if (flag == 2) {
      			flag = 3;
      			tmp |= (c & 0x3f) << 6; 
    		} else if (flag == 3) {
      			flag = 0;
      			d += String.fromCharCode(tmp | (c & 0x3f));
    		} else {
      			flag = 0;
    		}
  		}
  		
  		return d;
	}
	
}
